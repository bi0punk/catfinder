"""CatFinder MVP package."""
